package com.clakestudio.pc.fizykor.util.sharedprefs

interface ViewSharedPreferences {

    fun wasNavigationToastShowed(): Boolean

}