package com.clakestudio.pc.fizykor.data.source.remote.api

object URLManager {

    /**
     * Base when App is running on localhost
     * */
    const val base = "https://fizykor-ac84d.appspot.com"
    const val flashcards = "flashcards"
    const val equations = "equations"

}